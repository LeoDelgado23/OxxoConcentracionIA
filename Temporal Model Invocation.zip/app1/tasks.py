import ultralytics
ultralytics.checks()
from ultralytics import YOLO
import os
import io
import oracledb
from PIL import Image
from celery import shared_task
from datetime import datetime

def assign_error(connection, ml_id) :
  with connection.cursor() as cursor: 
    cursor.execute("UPDATE ML_WORKS SET work_status_code = 2 WHERE id_ml_work = :work_id", work_id = ml_id)
    
  connection.commit()

# Function that allow us to generate the suggestions based on the predictions
# and the real distribution configuration.
def generate_suggestions(detection_dic, configuration_dic):    
  detected_items = 0
  suggestions_dic = {}
    
  # Iterate for all the values in detections.
  # Comparing Detection Dictionary vs Configuration Dictionary
  for key, value in detection_dic.items():
    # If item detected is actually in the configuration dictionary (expected item).
    if key in configuration_dic :
      # If the number of detections of that item is different.
      if (detection_dic[key] != configuration_dic[key]):
        # Count the correct preditions (TP) and calculate the difference to make a suggestion.
        detected_items += value
        diff = detection_dic[key] - configuration_dic[key]
                
        if (diff > 0):
          message = 'Detecte ' + str(diff) + ' items de más para este producto.'
          detected_items -= diff
        else :
          message = 'Hacen falta ' + str(abs(diff)) + ' items para este producto.'
                
          suggestions_dic[key] = message
      else :
        # If the number of detections of that item is correct.
        detected_items += configuration_dic[key]
    else :
      # If detected item is unexpected.
      suggestions_dic[key] = 'Producto detectado no esta en configuracion.'
    
  # Now compare Configuration vs Detection (Expected items that were not detected.)
  missing_configuration = set(configuration_dic.keys()) - set(detection_dic.keys())
  for key in missing_configuration:
    suggestions_dic[key] = 'No identifique el producto en el estante. Revisar configuracion.'
    
  return [suggestions_dic, detected_items]

@shared_task
def my_periodic_task():
  #print(f"My periodic task ran at {datetime.now()}")
  base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

  model_path = os.path.join(base_dir, 'yoloWeights', 'best.pt').replace("\\", "/")
  print(model_path)

  # Connection to the autonomous database.
  try :
    connection = oracledb.connect(
      user = "OXXO_TESTING",
      password = "kSq&8371_Apx23",
      dsn = "(description= (retry_count=20)(retry_delay=3)(address=(protocol=tcps)(port=1522)(host=adb.us-phoenix-1.oraclecloud.com))(connect_data=(service_name=g0c4542b6212cd4_dboxxomlapp_medium.adb.oraclecloud.com))(security=(ssl_server_dn_match=yes)))"
    )
    print("Successfully connected to Oracle Database")
  except :
    print("Error: Making the Database Connection!")
    #data = {'message': 'Error: Making the Database Connection!'}
    return
  
  print("------------------")

  # Retrieve information of the Detection Work.
  try : 
    with connection.cursor() as cursor:
      cursor.execute('SELECT * FROM ML_WORKS WHERE WORK_STATUS_CODE = 0 ORDER BY ID_ML_WORK FETCH FIRST 1 ROW ONLY')
      ml_work_db = cursor.fetchone()
      #print(ml_work_db[2], "is the planogram, Content : ", ml_work_db[3])
            
      #Download the image to process.
      image_bytes = io.BytesIO(ml_work_db[4].read())
      im = Image.open(image_bytes)
      im.save('result.png')
      print("Image Downloaded Successfully.")
  except :
    print('Error: Retrieving Detection Work!')
    #data = {'message': 'Error: Retrieving Detection Work!'}
    return
    
  print("------------------")
  # Request a Prediction through our YOLO Model.
  try :
    model = YOLO(model_path)
    results = model('result.png', save = True, save_txt = True, save_conf = True)  # results list
    # View results in a specific directory.
    for r in results:
      predictions_path = r.save_dir
        
    print("Predictions Made by YOLO Successfully.")
  except:
    print('Error: Invoking our YOLO Model!')
    assign_error(connection, ml_work_db[0])
    #data = {'message': 'Error: Invoking our YOLO Model!'}
    return
  
  print("------------------")

  # Retrieve the predictions made by YOLO Model.
  try:
    prediction_image = predictions_path + '/result.png'
    prediction_text = predictions_path + '/labels/result.txt'
    prediction_file = open(prediction_text, 'r')
    prediction_lines = prediction_file.readlines()
        
    prediction_dic = {}
    prediction_precision = {}
    work_precision = 0
        
    for line in prediction_lines:
      prediction_line = line.split()
            
      work_precision += (float(prediction_line[5]) * 100)
            
      if prediction_line[0] in prediction_dic:
        prediction_dic[prediction_line[0]] += 1
      else :
        prediction_dic[prediction_line[0]] = 1
               
      if prediction_line[0] in prediction_precision:
        prediction_precision[prediction_line[0]] += (float(prediction_line[5]) * 100)
      else :
        prediction_precision[prediction_line[0]] = (float(prediction_line[5]) * 100)
        
    for key, value in prediction_dic.items() :
      prediction_precision[key] = float("{:.2f}".format(prediction_precision[key] / value))
        
    work_precision = float("{:.2f}".format(work_precision / sum(prediction_dic.values())))
        
    print("Predictions processed successfully.")
  except:
    print('Error: Retrieving the predictions files!')
    assign_error(connection, ml_work_db[0])
    #data = {'message': 'Error: Retrieving the predictions files!'}
    return
    
  print("------------------")

  # Retrieve information of the Distribution Configuration.
  try :
    with connection.cursor() as cursor:
      print(ml_work_db[2], " - ", ml_work_db[3])
      cursor.execute("SELECT * FROM PLANOGRAMAS_ITEMS WHERE CODE_PLANOGRAMA = :code_plano AND PLANOGRAMA_ESTANTE_CODE = :code_estante", code_plano = ml_work_db[2], code_estante = ml_work_db[3])
      planogramas_items_db = cursor.fetchall()
      actual_distribution = {}
      
      for row in planogramas_items_db:
        print(row[0], "is the planogram, Content : ", row[1], " product -> ", row[2])
        actual_distribution[str(row[2])] = row[3]
            
      print("Distribution Configuration Retrieved Successfully.")
  except :
    print('Error: Retrieving Distribution Configuration!')
    assign_error(connection, ml_work_db[0])
    #data = {'message': 'Error: Retrieving Distribution Configuration!'}
    return
    
  print("------------------")

  # Calculate scores and suggestions.
  try:
    print(prediction_dic)
    print(actual_distribution)
    suggestions, detected_items = generate_suggestions(prediction_dic, actual_distribution)
    score = float("{:.2f}".format(detected_items * 100 / sum(actual_distribution.values())))
        
    print("Suggestions Generated Successfully.")
  except:
    print('Error: Calculating the Scores and Suggestions!')
    assign_error(connection, ml_work_db[0])
    #data = {'message': 'Error: Calculating the Scores and Suggestions!'}
    return
    
  print("------------------")

  # Retrieve predictions image.
  try:
    with open(prediction_image, 'rb') as f:
      prediction_image_data = f.read()
            
    print("Image Retrieve Successfully.")
  except:
    print('Error: Retrieving the Predictions Image!')
    assign_error(connection, ml_work_db[0])
    #data = {'message': 'Error: Retrieving the Predictions Image!'}
    return
    
  print("------------------")

  # Commit tables of the database.
  try:
    with connection.cursor() as cursor:
      for key, value in suggestions.items() :
        if key in prediction_dic:
          cursor.execute("INSERT INTO ML_RESULTS(id_ml_work, result_image, product_code, product_count, result_suggestion, result_precision) VALUES (:work_id, :my_image, :code_prod, :count_prod, :sugg_res, :pres_res)", work_id = ml_work_db[0], my_image = prediction_image_data, code_prod = int(key), count_prod = prediction_dic[key], sugg_res = suggestions[key], pres_res = prediction_precision[key])
        else :
          cursor.execute("INSERT INTO ML_RESULTS(id_ml_work, result_image, product_code, product_count, result_suggestion, result_precision) VALUES (:work_id, :my_image, :code_prod, 0, :sugg_res, 0)", work_id = ml_work_db[0], my_image = prediction_image_data, code_prod = int(key), sugg_res = suggestions[key])
    connection.commit()
        
    print("Commit Made Successfully.")
  except:
    print('Error: Commiting to database!')
    assign_error(connection, ml_work_db[0])
    #data = {'message': 'Error: Commiting to database!'}
    return
    
  print("------------------")

  # Update tables of the database.
  try:    
    with connection.cursor() as cursor: 
      cursor.execute("UPDATE ML_WORKS SET work_status_code = 1, work_confidence = :work_conf, work_accomodattion = :work_acomm WHERE id_ml_work = :work_id", work_id = ml_work_db[0], work_conf = work_precision, work_acomm = score)
    
    connection.commit()
      
    print("Update Made Successfully.")
  except:
    print('Error: Updating to database!')
    assign_error(connection, ml_work_db[0])
    #data = {'message': 'Error: Updating to database!'}
    return 
  
  #data = {'message': 'Prediction Wok Finished Succesfully.'}
  print('Prediction Wok Finished Succesfully.')
  return